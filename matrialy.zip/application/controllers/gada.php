<?php
class Gada extends CI_Controller
{
	public function index()
	{
		$this->load->view('error.php');
	}
}
